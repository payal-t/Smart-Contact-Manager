
public class MyConfig {

}
